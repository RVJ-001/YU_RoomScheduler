package roomscheduler_repository;

import roomscheduler_model_user.User;
import roomscheduler_observer.Subject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class UserRepository extends Subject {
    private static final UserRepository INSTANCE = new UserRepository();
    public static UserRepository getInstance() { return INSTANCE; }

    private final Map<String, User> byEmail = new HashMap<>();
    private final Map<String, User> byId    = new HashMap<>();

    private final File csvFile = new File("users.csv");

    private UserRepository(){ readAll(); }

    public synchronized void addUser(User u){
        byEmail.put(u.getEmail().toLowerCase(Locale.ROOT), u);
        byId.put(u.getId(), u);
        writeAll();
        notifyObservers();
    }

    public synchronized User findByEmail(String email){
        if (email == null) return null;
        return byEmail.get(email.toLowerCase(Locale.ROOT));
    }

    public synchronized Collection<User> findAll(){
        return Collections.unmodifiableCollection(byId.values());
    }

    // ------------- CSV -------------
    private synchronized void readAll(){
        byEmail.clear(); byId.clear();
        if (!csvFile.exists()) return;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(csvFile), StandardCharsets.UTF_8))){
            String header = br.readLine(); // id,name,email,password,type,orgId,verified
            for (String line; (line = br.readLine()) != null; ){
                if (line.trim().isEmpty()) continue;
                String[] w = parseCsvLine(line, 7);
                User u = new User(
                        w[0], w[1], w[2], w[3],
                        roomscheduler_model_user.UserType.valueOf(w[4]),
                        w[5], Boolean.parseBoolean(w[6]));
                byEmail.put(u.getEmail().toLowerCase(Locale.ROOT), u);
                byId.put(u.getId(), u);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to read users.csv: " + e.getMessage(), e);
        }
    }

    private synchronized void writeAll(){
        try (Writer w = new OutputStreamWriter(new FileOutputStream(csvFile, false), StandardCharsets.UTF_8)){
            w.write("id,name,email,password,type,orgId,verified\n");
            for (User u : byId.values()){
                w.write(csv(u.getId()) + "," + csv(u.getName()) + "," + csv(u.getEmail()) + ","
                        + csv(u.getPassword()) + "," + u.getType() + "," + csv(u.getOrgId()) + "," + u.isVerified() + "\n");
            }
        } catch (IOException ex){
            throw new RuntimeException("Failed to write users.csv: " + ex.getMessage(), ex);
        }
    }

    private static String csv(String s){
        if (s == null) return "";
        if (s.indexOf(',') < 0 && s.indexOf('"') < 0) return s;
        return "\"" + s.replace("\"","\"\"") + "\"";
    }

    private static String[] parseCsvLine(String line, int expected){
        List<String> out = new ArrayList<>(expected);
        StringBuilder sb = new StringBuilder();
        boolean inQ = false;
        for (int i=0;i<line.length();i++){
            char c = line.charAt(i);
            if (c=='"') inQ = !inQ;
            else if (c==',' && !inQ) { out.add(sb.toString()); sb.setLength(0); }
            else sb.append(c);
        }
        out.add(sb.toString());
        while (out.size()<expected) out.add("");
        return out.toArray(new String[0]);
    }
}
