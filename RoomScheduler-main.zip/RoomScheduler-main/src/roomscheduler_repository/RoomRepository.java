package roomscheduler_repository;

import java.util.*;
import java.util.stream.Collectors;

import roomscheduler_model_room.*;

public class RoomRepository extends roomscheduler_observer.Subject {
    private static final RoomRepository INSTANCE = new RoomRepository();
    public static RoomRepository getInstance(){ return INSTANCE; }

    private final List<Room> rooms = new ArrayList<>();

    public void addRoom(Room r){ rooms.add(r); notifyObservers(); }

    public List<Room> findBookable(){
        return rooms.stream().filter(Room::isBookable).collect(Collectors.toList());
    }

    public void enable(String id){ setStatus(id, RoomStatus.AVAILABLE); }
    public void disable(String id){ setStatus(id, RoomStatus.DISABLED); }
    public void setMaintenance(String id){ setStatus(id, RoomStatus.MAINTENANCE); }

    private void setStatus(String id, RoomStatus st) {
        rooms.stream().filter(r -> r.getId().equals(id)).findFirst().ifPresent(r -> {
            r.setStatus(st);
            if (st != RoomStatus.OCCUPIED && st != RoomStatus.BOOKED) r.setCurrentBooking(null);
            notifyObservers();
        });
    }

    public List<Room> findAll(){ return Collections.unmodifiableList(rooms); }
    public boolean isOperational(Room r){
        return r.getStatus() != RoomStatus.DISABLED && r.getStatus() != RoomStatus.MAINTENANCE;
    }
}
