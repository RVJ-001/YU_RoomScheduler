package roomscheduler_repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import roomscheduler_model.DateTimeRange;
import roomscheduler_model_booking.Booking;
import roomscheduler_model_booking.BookingStatus;
import roomscheduler_model_room.Room;
import roomscheduler_model_room.RoomStatus;
import roomscheduler_observer.Subject;

public class BookingRepository extends Subject {
    private static final BookingRepository INSTANCE = new BookingRepository();
    public static BookingRepository getInstance(){ return INSTANCE; }

    private final List<Booking> bookings = new ArrayList<>();

    public void addBooking(Booking b){ bookings.add(b); notifyObservers(); }

    public List<Booking> byUser(roomscheduler_model_user.User u){
        return bookings.stream()
                .filter(b -> b.getUser().equals(u))
                .sorted(Comparator.comparing(b -> b.getWhen().start()))
                .collect(Collectors.toList());
    }

    /* Check if a room is free for target; pass excludeBookingId when extending. */
    public boolean isRoomFree(Room room, DateTimeRange target, String excludeBookingId) {
        for (Booking b : bookings) {
            if (!b.getRoom().getId().equals(room.getId())) continue;
            if (excludeBookingId != null && excludeBookingId.equals(b.getBookingId())) continue;

            BookingStatus st = b.getStatus();
            if (st == BookingStatus.CANCELLED || st == BookingStatus.NO_SHOW) continue;

            if (target.overlaps(b.getWhen())) return false;
        }
        // respect room status
        return room.getStatus() != RoomStatus.DISABLED
            && room.getStatus() != RoomStatus.MAINTENANCE;
    }

    /* For Admin “Recent Usage” table. */
    public List<Booking> recentUsage(int limit){
        return bookings.stream()
                .filter(b -> b.getCheckInTime()!=null || b.getCheckOutTime()!=null)
                .sorted(Comparator.<Booking, java.time.LocalDateTime>comparing(
                        b -> b.getCheckOutTime()!=null ? b.getCheckOutTime() : b.getCheckInTime()
                ).reversed())
                .limit(limit)
                .collect(Collectors.toList());
    }
    public List<Booking> findAll(){ return Collections.unmodifiableList(bookings); }
}
