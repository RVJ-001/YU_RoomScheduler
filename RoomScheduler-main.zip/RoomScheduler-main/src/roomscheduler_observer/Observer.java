package roomscheduler_observer;
public interface Observer { void update(); }
