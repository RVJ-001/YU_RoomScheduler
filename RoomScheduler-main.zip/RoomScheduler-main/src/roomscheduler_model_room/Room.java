package roomscheduler_model_room;

import roomscheduler_model_booking.Booking;

public class Room {
    private final String id;
    private final String name;
    private final int capacity;
    private final String building;
    private final String roomNumber;

    private RoomState state = new AvailableState();
    private Booking currentBooking;

    public Room(String id, String name, int capacity, String building, String roomNumber) {
        this.id = id; this.name = name; this.capacity = capacity;
        this.building = building; this.roomNumber = roomNumber;
    }

    // --------- getters ----------
    public String getId() { return id; }
    public String getName() { return name; }
    public int getCapacity() { return capacity; }
    public String getBuilding() { return building; }
    public String getRoomNumber() { return roomNumber; }
    public Booking getCurrentBooking() { return currentBooking; }
    public void setCurrentBooking(Booking b) { this.currentBooking = b; }

    public RoomStatus getStatus() { return state.status(); }

    // --------- state plumbing ----------
    void setState(RoomState s) { this.state = s; }
    public void onBooked(Booking b)     { state.onBooked(this, b); }
    public void onCheckIn(Booking b)    { state.onCheckIn(this, b); }
    public void onCheckOut(Booking b)   { state.onCheckOut(this, b); }
    public void onMaintenance()         { state.onMaintenance(this); }
    public void onEnable()              { state.onEnable(this); }

    // Compatibility for code that still calls "setStatus(...)"
    public void setStatus(RoomStatus st) {
        switch (st) {
            case AVAILABLE:
                setState(new AvailableState());
                setCurrentBooking(null);
                break;
            case BOOKED:
                setState(new BookedState());
                break;
            case OCCUPIED:
                setState(new OccupiedState());
                break;
            case MAINTENANCE:
                setState(new MaintenanceState());
                setCurrentBooking(null);
                break;
            case DISABLED:
                setState(new DisabledState());
                setCurrentBooking(null);
                break;
        }
    }

    // used by RoomRepository.findBookable()
    public boolean isBookable() { return getStatus() == RoomStatus.AVAILABLE; }

    @Override public String toString() {
        return name + " (" + building + " " + roomNumber + ", " + capacity + " ppl, " + getStatus() + ")";
    }
}
