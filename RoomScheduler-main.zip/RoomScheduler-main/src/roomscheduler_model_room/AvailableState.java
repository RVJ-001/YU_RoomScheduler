package roomscheduler_model_room;

import roomscheduler_model_booking.Booking;

final class AvailableState implements RoomState {
    public RoomStatus status() { return RoomStatus.AVAILABLE; }
    public void onBooked(Room ctx, Booking b) { ctx.setState(new BookedState()); ctx.setCurrentBooking(b); }
    public void onCheckIn(Room ctx, Booking b) { ctx.setState(new OccupiedState()); ctx.setCurrentBooking(b); }
    public void onCheckOut(Room ctx, Booking b) { /* no-op */ }
    public void onMaintenance(Room ctx) { ctx.setState(new MaintenanceState()); }
    public void onEnable(Room ctx) { /* already enabled */ }
}
