package roomscheduler_model_room;

public enum RoomStatus {
    AVAILABLE, BOOKED, OCCUPIED, DISABLED, MAINTENANCE
}
