package roomscheduler_model_room;

import roomscheduler_model_booking.Booking;

final class DisabledState implements RoomState {
    public RoomStatus status() { return RoomStatus.DISABLED; }
    public void onBooked(Room ctx, Booking b) { /* blocked */ }
    public void onCheckIn(Room ctx, Booking b) { /* blocked */ }
    public void onCheckOut(Room ctx, Booking b) { /* blocked */ }
    public void onMaintenance(Room ctx) { /* blocked */ }
    public void onEnable(Room ctx) { ctx.setState(new AvailableState()); }
}
