package roomscheduler_model_room;

import roomscheduler_model_booking.Booking;

final class MaintenanceState implements RoomState {
    public RoomStatus status() { return RoomStatus.MAINTENANCE; }
    public void onBooked(Room ctx, Booking b) { /* blocked */ }
    public void onCheckIn(Room ctx, Booking b) { /* blocked */ }
    public void onCheckOut(Room ctx, Booking b) { /* blocked */ }
    public void onMaintenance(Room ctx) { /* already */ }
    public void onEnable(Room ctx) { ctx.setState(new AvailableState()); }
}
