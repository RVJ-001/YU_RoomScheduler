package roomscheduler_model_room;

import roomscheduler_model_booking.Booking;

public interface RoomState {
    RoomStatus status();
    void onBooked(Room ctx, Booking b);
    void onCheckIn(Room ctx, Booking b);
    void onCheckOut(Room ctx, Booking b);
    void onMaintenance(Room ctx);
    void onEnable(Room ctx);
}
