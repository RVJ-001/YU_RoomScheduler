package roomscheduler_model_room;

import roomscheduler_model_booking.Booking;

final class OccupiedState implements RoomState {
    public RoomStatus status() { return RoomStatus.OCCUPIED; }
    public void onBooked(Room ctx, Booking b) { /* ignore */ }
    public void onCheckIn(Room ctx, Booking b) { /* already in */ }
    public void onCheckOut(Room ctx, Booking b) { ctx.setState(new AvailableState()); ctx.setCurrentBooking(null); }
    public void onMaintenance(Room ctx) { ctx.setState(new MaintenanceState()); }
    public void onEnable(Room ctx) { /* already enabled and occupied */ }
}
