package roomscheduler_model_user;

import java.util.Objects;

public class User {
    private final String id;
    private final String name;
    private final String email;
    private final String password;   // demo: plain text per your spec
    private final UserType type;
    private final String orgId;      // student/employee id etc.
    private final boolean verified;

    public User(String id, String name, String email, String password,
                UserType type, String orgId, boolean verified){
        this.id = id; this.name = name; this.email = email;
        this.password = password; this.type = type;
        this.orgId = orgId; this.verified = verified;
    }

    public String getId(){ return id; }
    public String getName(){ return name; }
    public String getEmail(){ return email; }
    public String getPassword(){ return password; }
    public UserType getType(){ return type; }
    public String getOrgId(){ return orgId; }
    public boolean isVerified(){ return verified; }
    

    public boolean checkPassword(String raw){ return Objects.equals(password, raw); }
}
