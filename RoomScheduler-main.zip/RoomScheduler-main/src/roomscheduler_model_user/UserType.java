package roomscheduler_model_user;

/** Matches the UML (stand-alone enum, not nested). */
public enum UserType {
    STUDENT, FACULTY, STAFF, PARTNER, ADMIN, CEC
}
