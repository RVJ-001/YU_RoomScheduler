package roomscheduler_model_user;

public final class UserFactory {
    private UserFactory(){}

    /** Unified signature used across your codebase. */
    public static User createUser(UserType type, String id, String name, String email,
                                  String password, String orgId, boolean verified){
        if (type == UserType.ADMIN) {
            return new Admin(id, name, email, password);
        }
        return new User(id, name, email, password, type, orgId, verified);
    }
}
