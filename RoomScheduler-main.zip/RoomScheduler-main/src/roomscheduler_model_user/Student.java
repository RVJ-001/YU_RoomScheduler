package roomscheduler_model_user;
public class Student extends User {
  public Student(String id, String name, String email, String password,
                 String studentNumber, boolean verified) {
    super(id, name, email, password, UserType.STUDENT, studentNumber, verified);
  }
  public double getHourlyRate(){ return 20.0; }
}
