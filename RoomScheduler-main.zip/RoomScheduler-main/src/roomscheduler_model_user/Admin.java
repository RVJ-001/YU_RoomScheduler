package roomscheduler_model_user;

public class Admin extends User {
    public Admin(String id, String name, String email, String password){
        super(id, name, email, password, UserType.ADMIN, "", true);
    }
}
