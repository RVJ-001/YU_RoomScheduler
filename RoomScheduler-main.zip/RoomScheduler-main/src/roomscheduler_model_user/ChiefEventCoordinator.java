package roomscheduler_model_user;

/** CEC is a singleton (there is exactly one). */
public final class ChiefEventCoordinator extends Admin {
    private static ChiefEventCoordinator INSTANCE;

    private ChiefEventCoordinator(String id, String name, String email, String pwd) {
        super(id, name, email, pwd);
    }

    /** First call constructs; later calls return the same instance. */
    public static synchronized ChiefEventCoordinator getInstance(
            String id, String name, String email, String pwd) {
        if (INSTANCE == null) INSTANCE = new ChiefEventCoordinator(id, name, email, pwd);
        return INSTANCE;
    }
}
