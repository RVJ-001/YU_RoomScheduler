package roomscheduler_model_user;
public class Faculty extends User {
  public Faculty(String id, String name, String email, String password,
                 String facultyId, boolean verified) {
    super(id, name, email, password, UserType.FACULTY, facultyId, verified);
  }
  public double getHourlyRate(){ return 30.0; }
}
