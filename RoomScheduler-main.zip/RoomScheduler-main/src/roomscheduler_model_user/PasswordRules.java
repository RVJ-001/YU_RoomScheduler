package roomscheduler_model_user;

public final class PasswordRules {
    private PasswordRules(){}
    public static boolean strong(String pwd){
        // Simple demo rule: 6+ chars. Adjust as needed.
        return pwd != null && pwd.length() >= 6;
    }
}
