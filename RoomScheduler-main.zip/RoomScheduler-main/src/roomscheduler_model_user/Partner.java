package roomscheduler_model_user;
public class Partner extends User {
  public Partner(String id, String name, String email, String password,
                 String partnerId, boolean verified) {
    super(id, name, email, password, UserType.PARTNER, partnerId, verified);
  }
  public double getHourlyRate(){ return 50.0; }
}
