package roomscheduler_model_user;
public class Staff extends User {
  public Staff(String id, String name, String email, String password,
               String staffId, boolean verified) {
    super(id, name, email, password, UserType.STAFF, staffId, verified);
  }
  public double getHourlyRate(){ return 40.0; }
}
