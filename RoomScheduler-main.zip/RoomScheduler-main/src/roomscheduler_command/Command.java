package roomscheduler_command;

public interface Command {
    void execute();
}
