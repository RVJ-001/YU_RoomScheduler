package roomscheduler_command;

import java.time.LocalDateTime;

import roomscheduler_controller.SystemController;
import roomscheduler_model_booking.Booking;
import roomscheduler_model_payment.CreditCardPayment;
import roomscheduler_model_payment.PaymentMethod;
import roomscheduler_model_room.Room;

public class BookRoomCommand implements Command {
    private final SystemController controller;
    private final Room room;

    public BookRoomCommand(SystemController controller, Room room) {
        this.controller = controller;
        this.room = room;
    }

    @Override
    public void execute() {
        LocalDateTime now = LocalDateTime.now().plusMinutes(5);
        LocalDateTime end = now.plusHours(1);
        PaymentMethod pm = new CreditCardPayment("4111111111111111","Demo","12/29","123");
        Booking booking = controller.bookRoom(room, now, end, pm);
        System.out.println("Booked: " + booking.getBookingId() + " for room " + room.getName());
    }
}
