package roomscheduler_model;

import java.time.LocalDateTime;

public final class DateTimeRange {
  private final LocalDateTime start, end;
  public DateTimeRange(LocalDateTime start, LocalDateTime end) {
    if (start == null || end == null || !end.isAfter(start))
      throw new IllegalArgumentException("Invalid time range");
    this.start = start; this.end = end;
  }
  public LocalDateTime start() { return start; }
  public LocalDateTime end() { return end; }

  public boolean overlaps(DateTimeRange other) {
    return !end.isEqual(other.start) && !other.end.isEqual(start)
        && end.isAfter(other.start) && other.end.isAfter(start);
  }
}
