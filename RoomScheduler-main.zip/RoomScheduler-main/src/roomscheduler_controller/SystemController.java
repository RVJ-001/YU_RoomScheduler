package roomscheduler_controller;

import java.time.LocalDateTime;
import java.util.*;
import roomscheduler_model.DateTimeRange;
import roomscheduler_model_booking.*;
import roomscheduler_model_payment.*;
import roomscheduler_model_room.*;
import roomscheduler_model_user.*;
import roomscheduler_repository.*;

public class SystemController {

  private static final SystemController INSTANCE = new SystemController();
  public static SystemController getInstance(){ return INSTANCE; }

  private static final String CEC_EMAIL = "cec@yorku.ca";
  private static final String CEC_NAME  = "Chief Event Coordinator";

  private final UserRepository userRepo = UserRepository.getInstance();
  private final RoomRepository roomRepo = RoomRepository.getInstance();
  private final BookingRepository bookingRepo = BookingRepository.getInstance();
  private final SensorService sensor = new SensorService();

  private User currentUser;

  private SystemController(){ seed(); }

  private void seed() {
    if (!userRepo.findAll().isEmpty()) return;

    User cec = new User(UUID.randomUUID().toString(), CEC_NAME, CEC_EMAIL,
        "cec123", UserType.ADMIN, "ENG", true);
    userRepo.addUser(cec);

    User sampleUser = new User(UUID.randomUUID().toString(), "Alice Student",
        "alice@my.yorku.ca", "pass", UserType.STUDENT, "S1234567", true);
    userRepo.addUser(sampleUser);

    User sampleAdmin = new User(UUID.randomUUID().toString(), "Admin One",
        "admin@yorku.ca", "admin123", UserType.ADMIN, "ENG", true);
    userRepo.addUser(sampleAdmin);

    roomRepo.addRoom(new Room("R1","Conference A",10,"ENG","A101"));
    roomRepo.addRoom(new Room("R2","Conference B",20,"ENG","A102"));
  }

  // -------- auth --------
  public boolean login(String email, String password){
    User u = userRepo.findByEmail(email);
    if (u != null && u.checkPassword(password)) { currentUser = u; return true; }
    throw new IllegalArgumentException("Invalid email or password");
  }
  public void logout(){ currentUser = null; }
  public User getCurrentUser(){ return currentUser; }

  // Register (public)
  public User register(String name, String email, String password,
                       UserType type, String orgId, boolean verified) {
    if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Name required");
    if (email == null || email.trim().isEmpty()) throw new IllegalArgumentException("Email required");
    if (userRepo.findByEmail(email) != null) throw new IllegalArgumentException("Email already in use");
    if (!PasswordRules.strong(password)) throw new IllegalArgumentException("Weak password");
    User u = new User(UUID.randomUUID().toString(), name.trim(), email.trim(), password,
                      type, orgId == null ? "" : orgId.trim(), verified);
    userRepo.addUser(u);
    return u;
  }

  // ONLY CEC can create admins
  public void cecCreateAdmin(String cecEmail, String adminEmail, String adminPwd, String name) {
    if (!CEC_EMAIL.equalsIgnoreCase(cecEmail))
      throw new SecurityException("Only CEC can create admins");
    if (userRepo.findByEmail(adminEmail) != null)
      throw new IllegalArgumentException("Admin email already exists");
    User admin = new User(UUID.randomUUID().toString(), name, adminEmail, adminPwd,
                          UserType.ADMIN, "ENG", true);
    userRepo.addUser(admin);
  }

  // -------- browse --------
  public List<Room> getAvailableRooms(LocalDateTime start, LocalDateTime end){
    DateTimeRange when = new DateTimeRange(start, end);
    List<Room> out = new ArrayList<>();
    for (Room r : roomRepo.findAll()) {
      if (bookingRepo.isRoomFree(r, when, null)) out.add(r);
    }
    return out;
  }
  public List<Room> allRooms(){ return roomRepo.findAll(); }
  public List<Room> getOperationalRooms(){ return roomRepo.findAll(); }

  // -------- my bookings --------
  public List<Booking> getMyBookings() {
    ensureLoggedIn();
    return bookingRepo.byUser(currentUser);
  }
  public List<Booking> getBookingsForUser(User u) { return bookingRepo.byUser(u); }

  // -------- booking actions --------
  public Booking bookRoom(Room room, LocalDateTime start, LocalDateTime end, PaymentMethod pm) {
    ensureLoggedIn();
    if (room.getStatus() != RoomStatus.AVAILABLE) throw new IllegalStateException("Room not available");
    DateTimeRange when = new DateTimeRange(start, end);
    if (!bookingRepo.isRoomFree(room, when, null)) throw new IllegalStateException("Overlaps another booking");

    double cost = CostCalculator.compute(currentUser, when);
    double deposit = CostCalculator.deposit(cost);

    Payment depositPay = new Payment(deposit, pm);
    if (!depositPay.process()) throw new RuntimeException("Deposit payment failed");

    Booking booking = new Booking(UUID.randomUUID().toString(), currentUser, room, when, deposit, cost);
    booking.setStatus(BookingStatus.CONFIRMED);
    room.setStatus(RoomStatus.BOOKED);
    room.setCurrentBooking(booking);

    bookingRepo.addBooking(booking);
    roomRepo.notifyObservers();
    bookingRepo.notifyObservers();

    sensor.scheduleNoShowAutoCancel(booking);
    return booking;
  }

  public Booking extendBooking(Booking booking, LocalDateTime newEnd, PaymentMethod pm) {
    ensureLoggedIn();
    DateTimeRange newRange = new DateTimeRange(booking.getWhen().start(), newEnd);
    if (!bookingRepo.isRoomFree(booking.getRoom(), newRange, booking.getBookingId()))
      throw new IllegalStateException("Extension not available");
    double newCost = CostCalculator.compute(booking.getUser(), newRange);
    double extra = Math.max(0, newCost - booking.getTotalCost());
    if (extra > 0) {
      Payment p = new Payment(extra, pm);
      if (!p.process()) throw new RuntimeException("Extension payment failed");
    }
    booking.extendTo(newRange, newCost);
    bookingRepo.notifyObservers();
    return booking;
  }

  public void cancelBooking(Booking booking) {
    ensureLoggedIn();
    if (booking.getStatus()==BookingStatus.CANCELLED || booking.getStatus()==BookingStatus.NO_SHOW) return;
    if (LocalDateTime.now().isAfter(booking.getWhen().start()))
      throw new IllegalStateException("Booking already started");
    booking.setStatus(BookingStatus.CANCELLED);
    booking.getRoom().setCurrentBooking(null);
    booking.getRoom().setStatus(RoomStatus.AVAILABLE);
    roomRepo.notifyObservers();
    bookingRepo.notifyObservers();
  }

  public void checkIn(Booking booking, String badgeId) {
    ensureLoggedIn();
    if (booking.getStatus() != BookingStatus.CONFIRMED) throw new IllegalStateException("Not eligible");
    if (LocalDateTime.now().isAfter(booking.getWhen().start().plusMinutes(30)))
      throw new IllegalStateException("Late >30m; deposit lost");
    if (sensor.scanBadge(booking, badgeId)) {
      booking.setStatus(BookingStatus.CHECKED_IN);
      booking.markCheckedIn(LocalDateTime.now());
      booking.getRoom().setStatus(RoomStatus.OCCUPIED);
      bookingRepo.notifyObservers(); roomRepo.notifyObservers();
    } else throw new IllegalStateException("Badge verification failed");
  }

  public void checkOut(Booking booking) {
    ensureLoggedIn();
    booking.setStatus(BookingStatus.COMPLETED);
    booking.markCheckedOut(LocalDateTime.now());
    booking.getRoom().setStatus(RoomStatus.AVAILABLE);
    booking.getRoom().setCurrentBooking(null);

    double remaining = Math.max(0, booking.getTotalCost() - booking.getDepositAmount());
    if (remaining > 0) new Payment(remaining,
        new CreditCardPayment("4111111111111111", currentUser.getName(), "12/29", "123")).process();

    roomRepo.notifyObservers(); bookingRepo.notifyObservers();
  }

  // -------- admin dashboards --------
  public List<Booking> adminRecentUsage(int max){
    List<Booking> all = new ArrayList<>(BookingRepository.getInstance().findAll());
    all.sort(Comparator.comparing(b -> b.getWhen().start()));
    Collections.reverse(all);
    if (max < 0 || max >= all.size()) return all;
    return new ArrayList<>(all.subList(0, max));
  }

  // ---- room ops (Admin or CEC) ----
  public void adminEnableRoom(String roomId){ ensureAdminOrCEC(); setRoomStatus(roomId, RoomStatus.AVAILABLE); }
  public void adminDisableRoom(String roomId){ ensureAdminOrCEC(); setRoomStatus(roomId, RoomStatus.DISABLED); }
  public void adminMaintenance(String roomId){ ensureAdminOrCEC(); setRoomStatus(roomId, RoomStatus.MAINTENANCE); }

  private void setRoomStatus(String roomId, RoomStatus status){
    for (Room r : roomRepo.findAll()){
      if (r.getId().equals(roomId)) {
        r.setStatus(status);
        if (status != RoomStatus.BOOKED) r.setCurrentBooking(null);
        roomRepo.notifyObservers();
        return;
      }
    }
    throw new IllegalArgumentException("Room not found: " + roomId);
  }

  // guards
  private void ensureLoggedIn(){ if (currentUser == null) throw new IllegalStateException("Login required"); }
  private void ensureAdminOrCEC(){
    ensureLoggedIn();
    boolean isCEC = CEC_EMAIL.equalsIgnoreCase(currentUser.getEmail());
    boolean isAdmin = currentUser instanceof Admin;
    if (!(isCEC || isAdmin)) throw new SecurityException("Admin/CEC only");
  }
}
