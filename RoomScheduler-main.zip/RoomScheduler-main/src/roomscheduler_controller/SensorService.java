package roomscheduler_controller;

import java.time.*;
import java.util.*;

import roomscheduler_model_booking.*;
import roomscheduler_model_room.*;
import roomscheduler_repository.BookingRepository;

class SensorService {
    private final BookingRepository bookingRepo = BookingRepository.getInstance();
    private final Timer timer = new Timer("no-show", true);

    void scheduleNoShowAutoCancel(Booking booking) {
        LocalDateTime deadline = booking.getWhen().start().plusMinutes(30);
        long delayMs = Math.max(0, Duration.between(LocalDateTime.now(), deadline).toMillis());
        timer.schedule(new TimerTask() {
            @Override public void run() {
                if (booking.getStatus() == BookingStatus.CONFIRMED) {
                    booking.setStatus(BookingStatus.NO_SHOW);
                    booking.getRoom().setStatus(RoomStatus.AVAILABLE);
                    bookingRepo.notifyObservers();
                }
            }
        }, delayMs);
    }

    boolean scanBadge(Booking b, String badgeId){ b.setCheckInBadge(badgeId); return true; }
}
