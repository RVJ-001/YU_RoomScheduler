package roomscheduler_controller;

public final class PasswordRules {
  private PasswordRules() {}
  // ≥8 chars, at least one upper, one lower, one digit, one symbol
  public static boolean strong(String s) {
    if (s == null || s.length() < 8) return false;
    boolean up=false, lo=false, di=false, sy=false;
    for (char c: s.toCharArray()) {
      if (Character.isUpperCase(c)) up = true;
      else if (Character.isLowerCase(c)) lo = true;
      else if (Character.isDigit(c)) di = true;
      else sy = true;
    }
    return up && lo && di && sy;
  }
}
