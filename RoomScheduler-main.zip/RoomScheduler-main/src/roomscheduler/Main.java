package roomscheduler;

import javax.swing.SwingUtilities;
import roomscheduler_view.MainFrame;
import javax.swing.*;

public class Main {
public static void main(String[] args) {
 // Avoid the macOS “screen menu bar” + Aqua painting bug
 System.setProperty("apple.laf.useScreenMenuBar", "false");

 SwingUtilities.invokeLater(() -> {
   MainFrame.installLookAndFeel();     // set LAF FIRST
   MainFrame f = new MainFrame();      // then build the UI
   f.setVisible(true);
 });
}
}
