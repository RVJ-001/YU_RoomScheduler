package roomscheduler_view;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.util.List;

import roomscheduler_controller.SystemController;
import roomscheduler_model_booking.Booking;
import roomscheduler_model_user.User;

public class MyBookingsPanel extends JPanel {
  private static final long serialVersionUID = 1L;

  private final SystemController controller;
  private final TableModel model = new TableModel();
  private final JTable table = new JTable(model);
  private final JLabel msg = new JLabel("Please log in to see your bookings.");

  public MyBookingsPanel(SystemController controller) {
    super(new BorderLayout(8,8));
    this.controller = controller;
    add(new JScrollPane(table), BorderLayout.CENTER);
    add(msg, BorderLayout.SOUTH);
  }

  public void reload() {
    try {
      User u = controller.getCurrentUser();
      if (u == null) {
        model.setData(java.util.Collections.emptyList());
        msg.setText("Please log in to see your bookings.");
        return;
      }
      List<Booking> list = controller.getBookingsForUser(u);
      if (list == null) list = java.util.Collections.emptyList();
      model.setData(list);
      msg.setText("Bookings: " + list.size());
    } catch (Throwable t) {
      model.setData(java.util.Collections.emptyList());
      msg.setText(t.getMessage());
    }
  }

  private static final class TableModel extends AbstractTableModel {
    private List<Booking> data = java.util.Collections.emptyList();
    private final String[] cols = {"Room","Start","Check-in","Check-out","Used (min)"};
    void setData(List<Booking> d){ data = d; fireTableDataChanged(); }
    @Override public int getRowCount(){ return data.size(); }
    @Override public int getColumnCount(){ return cols.length; }
    @Override public String getColumnName(int c){ return cols[c]; }
    @Override public Object getValueAt(int r,int c){
      Booking b = data.get(r);
      switch(c){
        case 0: return b.getRoom().getName();
        case 1: return b.getWhen().start();
        case 2: return b.getCheckInTime();
        case 3: return b.getCheckOutTime();
        case 4: return b.usedMinutes();
        default: return "";
      }
    }
  }
}
