package roomscheduler_view;

import javax.swing.*;
import java.awt.*;
import java.time.*;
import java.util.Date;
import java.util.List;

import roomscheduler_controller.SystemController;
import roomscheduler_model_room.Room;
import roomscheduler_model_payment.PaymentMethod;

public class BookingPanel extends JPanel {
  private static final long serialVersionUID = 1L;

  private final SystemController controller;
  private final DefaultListModel<Room> roomsModel = new DefaultListModel<>();
  private final JList<Room> roomsList = new JList<>(roomsModel);

  private final JSpinner startSpin;
  private final JSpinner endSpin;
  private final JLabel msg = new JLabel(" ");

  public BookingPanel(SystemController controller) {
    super(new BorderLayout(10,10));
    this.controller = controller;

    // time pickers
    Date nowPlus5 = Date.from(Instant.now().plusSeconds(300));
    startSpin = new JSpinner(new SpinnerDateModel(nowPlus5, null, null, java.util.Calendar.MINUTE));
    endSpin   = new JSpinner(new SpinnerDateModel(Date.from(nowPlus5.toInstant().plusSeconds(3600)), null, null, java.util.Calendar.MINUTE));
    startSpin.setEditor(new JSpinner.DateEditor(startSpin, "yyyy-MM-dd HH:mm"));
    endSpin.setEditor(new JSpinner.DateEditor(endSpin, "yyyy-MM-dd HH:mm"));

    JButton refresh = new JButton("Refresh");
    refresh.addActionListener(e -> refresh());

    JButton book = new JButton("Book Selected Room");
    book.addActionListener(e -> onBook());

    JPanel right = new JPanel(new GridLayout(0,1,6,6));
    right.setBorder(BorderFactory.createTitledBorder("Choose Time"));
    right.add(new JLabel("Start:"));
    right.add(startSpin);
    right.add(new JLabel("End:"));
    right.add(endSpin);

    JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
    top.add(book);
    top.add(refresh);

    add(top, BorderLayout.NORTH);
    add(new JScrollPane(roomsList), BorderLayout.CENTER);
    add(right, BorderLayout.EAST);
    add(msg, BorderLayout.SOUTH);
  }

  public void refreshForNow(){ refresh(); }

  private void refresh(){
    roomsModel.clear();
    LocalDateTime s = LocalDateTime.ofInstant(((Date)startSpin.getValue()).toInstant(), ZoneId.systemDefault());
    LocalDateTime e = LocalDateTime.ofInstant(((Date)endSpin.getValue()).toInstant(), ZoneId.systemDefault());
    List<Room> avail = controller.getAvailableRooms(s, e);
    for (Room r : avail) roomsModel.addElement(r);
    msg.setText("Rooms available: " + avail.size());
  }

  private void onBook(){
    Room r = roomsList.getSelectedValue();
    if (r == null) { msg.setText("Select a room."); return; }
    LocalDateTime s = LocalDateTime.ofInstant(((Date)startSpin.getValue()).toInstant(), ZoneId.systemDefault());
    LocalDateTime e = LocalDateTime.ofInstant(((Date)endSpin.getValue()).toInstant(), ZoneId.systemDefault());
    try {
      double preview = 1.0; // just for the dialog header
      PaymentMethod pm = PaymentDialog.prompt(this, preview);
      if (pm == null) return;
      controller.bookRoom(r, s, e, pm);
      msg.setText("Booked.");
      refresh();
    } catch (Exception ex) { msg.setText(ex.getMessage()); }
  }
}
