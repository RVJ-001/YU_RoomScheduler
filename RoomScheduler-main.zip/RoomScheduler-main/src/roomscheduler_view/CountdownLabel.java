package roomscheduler_view;

import javax.swing.*;
import java.time.*;

public class CountdownLabel extends JLabel {
  private static final long serialVersionUID = 1L;
  private Timer t;
  private java.util.function.Supplier<LocalDateTime> endSupplier;

  public void bind(java.util.function.Supplier<LocalDateTime> endSupplier){
    this.endSupplier = endSupplier;
    if (t != null) t.stop();
    t = new Timer(1000, e -> tick());
    t.start();
  }

  private void tick(){
    if (endSupplier == null) { setText(""); return; }
    LocalDateTime end = endSupplier.get();
    long secs = Duration.between(LocalDateTime.now(), end).getSeconds();
    if (secs <= 0) { setText("Time left: 00:00:00"); t.stop(); }
    else {
      long h=secs/3600, m=(secs%3600)/60, s=secs%60;
      setText(String.format("Time left: %02d:%02d:%02d", h,m,s));
    }
  }
}
