package roomscheduler_view;

import javax.swing.*;
import java.awt.*;
import roomscheduler_model_payment.*;

public class PaymentDialog {
  public static PaymentMethod prompt(Component parent, double amount){
    String[] methods = {"Credit Card","Debit Card","Institutional Billing"};
    JComboBox<String> method = new JComboBox<>(methods);
    JTextField number = new JTextField();
    JTextField name   = new JTextField();
    JTextField expiry = new JTextField("12/29");
    JTextField cvv    = new JTextField("123");
    JTextField dept   = new JTextField();

    JPanel p = new JPanel(new GridLayout(0,2,6,6));
    p.add(new JLabel("Pay $" + String.format("%.2f", amount))); p.add(new JLabel());
    p.add(new JLabel("Method:"));                 p.add(method);
    p.add(new JLabel("Card/Acct No:"));           p.add(number);
    p.add(new JLabel("Name/Dept:"));              p.add(name);
    p.add(new JLabel("Expiry (mm/yy):"));         p.add(expiry);
    p.add(new JLabel("CVV (if card):"));          p.add(cvv);
    p.add(new JLabel("Institution Dept (if billing):")); p.add(dept);

    int ok = JOptionPane.showConfirmDialog(parent, p, "Payment", JOptionPane.OK_CANCEL_OPTION);
    if (ok != JOptionPane.OK_OPTION) return null;

    String m = (String) method.getSelectedItem();
    if ("Credit Card".equals(m))
      return new CreditCardPayment(number.getText().trim(), name.getText().trim(),
                                   expiry.getText().trim(), cvv.getText().trim());
    if ("Debit Card".equals(m))
      return new DebitCardPayment(number.getText().trim(), name.getText().trim(),
                                  expiry.getText().trim());

    // Institutional billing: support dept + optional reference/account no.
    return new InstitutionalBilling(dept.getText().trim(), number.getText().trim());
  }
}
