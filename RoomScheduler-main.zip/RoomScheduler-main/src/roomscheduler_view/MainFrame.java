package roomscheduler_view;

import javax.swing.*;
import java.awt.*;
import roomscheduler_controller.SystemController;
import roomscheduler_model_user.Admin;
import roomscheduler_model_user.User;
import javax.swing.border.Border;
import javax.swing.BorderFactory;

public class MainFrame extends JFrame {
  private static final long serialVersionUID = 1L;

  private final SystemController controller = SystemController.getInstance();
  
  private static final Border SAFE_MI_BORDER = BorderFactory.createEmptyBorder(2, 8, 2, 8);

  private final CardLayout cardsLayout = new CardLayout();
  private final JPanel cards = new JPanel(cardsLayout);

  private LoginPanel loginPanel;
  private RegisterPanel registerPanel;
  private BookingPanel bookingPanel;
  private MyBookingsPanel myBookingsPanel;
  private AdminPanel roomOpsPanel;               // Rooms & Usage
  private CecAdminAccountsPanel cecAdminPanel;   // CEC: Admin Accounts

  private final JMenuItem mBook       = new JMenuItem("Book");
  private final JMenuItem mMine       = new JMenuItem("My Bookings");
  private final JMenuItem mOps        = new JMenuItem("Rooms & Usage");
  private final JMenuItem mCecAdmins  = new JMenuItem("CEC: Admin Accounts");
  private final JMenuItem mRegister   = new JMenuItem("Register");
  private final JMenuItem mLogout     = new JMenuItem("Logout");

  public MainFrame() {
    super("YorkU Room Scheduler");
    installLookAndFeel();

    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    setSize(1000, 650);
    setLocationRelativeTo(null);

    // screens
    loginPanel      = new LoginPanel(this, controller);
    registerPanel   = new RegisterPanel(this, controller);
    bookingPanel    = new BookingPanel(controller);
    myBookingsPanel = new MyBookingsPanel(controller);
    roomOpsPanel    = new AdminPanel(controller);
    cecAdminPanel   = new CecAdminAccountsPanel(controller);

    cards.add(loginPanel,      "login");
    cards.add(registerPanel,   "register");
    cards.add(bookingPanel,    "book");
    cards.add(myBookingsPanel, "mine");
    cards.add(roomOpsPanel,    "ops");
    cards.add(cecAdminPanel,   "cec-admins");

    setContentPane(cards);
    setJMenuBar(buildMenu());

    showCard("login");
    updateMenuForRole();
  }

  private JMenuBar buildMenu() {
	  JMenuBar bar = new JMenuBar();
	  JMenu nav = new JMenu("Navigate");
	  bar.add(nav);

	  nav.add(mBook);
	  nav.add(mMine);
	  nav.add(mOps);
	  nav.add(mCecAdmins);
	  nav.addSeparator();
	  nav.add(mRegister);
	  nav.add(mLogout);

	  // Safety: explicit, non-null borders for Aqua painting
	  Border SAFE_MI_BORDER = BorderFactory.createEmptyBorder(2, 8, 2, 8);
	  for (JMenuItem mi : new JMenuItem[]{ mBook, mMine, mOps, mCecAdmins, mRegister, mLogout }) {
	    mi.setBorder(SAFE_MI_BORDER);
	    mi.setBorderPainted(true);
	  }

	  // Actions
	  mBook.addActionListener(e -> { showCard("book");    bookingPanel.refreshForNow(); });
	  mMine.addActionListener(e -> { showCard("mine");    myBookingsPanel.reload();    });
	  mOps.addActionListener(e  -> { showCard("ops");     roomOpsPanel.reload();       });
	  mCecAdmins.addActionListener(e -> showCard("cec-admins"));
	  mRegister.addActionListener(e -> showCard("register"));
	  mLogout.addActionListener(e -> {
	    controller.logout();
	    showCard("login");
	    updateMenuForRole();
	  });

	  return bar;
	}


  private void showCard(String key){
    cardsLayout.show(cards, key);
    cards.revalidate();
    cards.repaint();
  }

  public void updateMenuForRole(){
    User u = controller.getCurrentUser();
    boolean loggedIn = (u != null);
    boolean isAdmin = loggedIn && (u instanceof Admin);
    boolean isCEC   = loggedIn && "cec@yorku.ca".equalsIgnoreCase(u.getEmail());

    mBook.setEnabled(loggedIn);
    mMine.setEnabled(loggedIn);
    mOps.setEnabled(loggedIn && (isAdmin || isCEC));
    mCecAdmins.setEnabled(loggedIn && isCEC);
    mLogout.setEnabled(loggedIn);
    mRegister.setEnabled(!loggedIn);
  }
  
  

  // helpers for child panels
  void goToLogin(){ showCard("login"); updateMenuForRole(); }
  void goToMine(){  showCard("mine");  updateMenuForRole(); }

  public static void installLookAndFeel() {
	  try {
	    UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
	  } catch (Exception ignore) {
	    try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
	    catch (Exception ignored) { /* last resort: leave default */ }
	  }

	  // Extra safety for menu items on macOS: give them a non-null border
	  UIManager.getLookAndFeelDefaults().put(
	      "MenuItem.border", javax.swing.BorderFactory.createEmptyBorder(2, 8, 2, 8));
	}


}
