package roomscheduler_view;

import javax.swing.*;
import java.awt.*;
import roomscheduler_controller.SystemController;

public class LoginPanel extends JPanel {
  private static final long serialVersionUID = 1L;

  private final SystemController controller;
  private final MainFrame frame;

  public LoginPanel(MainFrame frame, SystemController controller) {
    super(new GridBagLayout());
    this.frame = frame;
    this.controller = controller;

    JPanel card = new JPanel(new GridBagLayout());
    card.setBorder(BorderFactory.createEmptyBorder(24,24,24,24));

    JLabel title = new JLabel("YorkU Room Scheduler");
    title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));

    JTextField email = new JTextField(22);
    JPasswordField pwd = new JPasswordField(22);
    JCheckBox show = new JCheckBox("Show password");
    show.addActionListener(e -> pwd.setEchoChar(show.isSelected() ? (char)0 : '\u2022'));

    JButton login = new JButton("Log in");
    JButton toReg = new JButton("Create account");

    JLabel msg = new JLabel(" ");

    GridBagConstraints c = new GridBagConstraints();
    c.insets = new Insets(6,6,6,6);
    c.gridx=0; c.gridy=0; c.gridwidth=2; card.add(title,c);
    c.gridwidth=1; c.gridy++;
    card.add(new JLabel("Email:"), c); c.gridx=1; card.add(email,c);
    c.gridx=0; c.gridy++; card.add(new JLabel("Password:"), c);
    c.gridx=1; card.add(pwd,c);
    c.gridx=1; c.gridy++; card.add(show,c);
    c.gridx=1; c.gridy++; card.add(login,c);
    c.gridx=1; c.gridy++; card.add(toReg,c);
    c.gridx=0; c.gridy++; c.gridwidth=2; card.add(msg,c);

    login.addActionListener(e -> {
      try {
        controller.login(email.getText().trim(), new String(pwd.getPassword()));
        msg.setText("Welcome!");
        frame.goToMine();
      } catch (Exception ex){
        msg.setText(ex.getMessage());
      }
    });

    toReg.addActionListener(e -> frame.goToLogin()); // toggled via RegisterPanel

    GridBagConstraints root = new GridBagConstraints();
    root.insets = new Insets(12,12,12,12);
    add(card, root);
  }
}
