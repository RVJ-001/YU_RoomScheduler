package roomscheduler_view;

import javax.swing.*;
import java.awt.*;
import roomscheduler_controller.SystemController;
import roomscheduler_model_user.UserType;

public class RegisterPanel extends JPanel {
  private static final long serialVersionUID = 1L;

  public RegisterPanel(MainFrame frame, SystemController controller) {
    super(new BorderLayout(10,10));

    JTextField name = new JTextField();
    JTextField email = new JTextField();
    JPasswordField pwd = new JPasswordField();
    JTextField orgId = new JTextField();
    JComboBox<UserType> type = new JComboBox<>(UserType.values());
    JCheckBox verified = new JCheckBox("University account verified? (Students/Faculty/Staff)");

    JPanel form = new JPanel(new GridLayout(0,2,8,8));
    form.add(new JLabel("Name:"));          form.add(name);
    form.add(new JLabel("Email:"));         form.add(email);
    form.add(new JLabel("Password:"));      form.add(pwd);
    form.add(new JLabel("Org/Student #:")); form.add(orgId);
    form.add(new JLabel("Type:"));          form.add(type);
    form.add(new JLabel(" "));              form.add(verified);

    JButton reg = new JButton("Create Account");
    JButton goLogin = new JButton("Already a user? Login");
    JLabel msg = new JLabel(" ");

    reg.addActionListener(a -> {
      try {
        controller.register(
            name.getText().trim(),
            email.getText().trim(),
            new String(pwd.getPassword()),
            (UserType) type.getSelectedItem(),
            orgId.getText().trim(),
            verified.isSelected()
        );
        msg.setText("Account created. You can now log in.");
        frame.goToLogin();
      } catch (Exception ex) {
        msg.setText(ex.getMessage());
      }
    });

    goLogin.addActionListener(e -> frame.goToLogin());

    // Layout: buttons row above the status message
    JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
    buttons.add(reg);
    buttons.add(goLogin);

    JPanel south = new JPanel(new BorderLayout(0,6));
    south.add(buttons, BorderLayout.NORTH);
    south.add(msg, BorderLayout.SOUTH);

    add(form, BorderLayout.CENTER);
    add(south, BorderLayout.SOUTH);
  }
}
