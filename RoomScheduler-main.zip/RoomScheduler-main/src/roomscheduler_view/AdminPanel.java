package roomscheduler_view;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.List;

import roomscheduler_controller.SystemController;
import roomscheduler_model_booking.Booking;
import roomscheduler_model_room.Room;

public class AdminPanel extends JPanel {
  private static final long serialVersionUID = 1L;

  private final SystemController controller;
  private final DefaultListModel<Room> roomsModel = new DefaultListModel<>();
  private final JList<Room> roomsList = new JList<>(roomsModel);
  private final UsageModel usageModel = new UsageModel();
  private final JTable usageTable = new JTable(usageModel);
  private final JLabel msg = new JLabel(" ");

  public AdminPanel(SystemController controller) {
    super(new BorderLayout(8,8));
    this.controller = controller;

    JButton enable = new JButton("Enable");
    JButton disable = new JButton("Disable");
    JButton maint   = new JButton("Maintenance");
    JButton refresh = new JButton("Refresh");
    JButton export  = new JButton("Export CSV");

    enable.addActionListener(e -> onEnable());
    disable.addActionListener(e -> onDisable());
    maint.addActionListener(e -> onMaint());
    refresh.addActionListener(e -> reload());
    export.addActionListener(e -> onExport());

    JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
    top.add(enable); top.add(disable); top.add(maint); top.add(refresh); top.add(export);

    JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
        new JScrollPane(roomsList), new JScrollPane(usageTable));
    split.setResizeWeight(0.35);

    add(top, BorderLayout.NORTH);
    add(split, BorderLayout.CENTER);
    add(msg, BorderLayout.SOUTH);

    reload();
  }

  public void reload() {
    roomsModel.clear();
    List<Room> ops = controller.getOperationalRooms();
    if (ops != null) for (Room r : ops) roomsModel.addElement(r);
    usageModel.setData(controller.adminRecentUsage(200));
    msg.setText("Rooms: " + roomsModel.size());
  }

  private Room selected() { return roomsList.getSelectedValue(); }
  private void onEnable(){ Room r = selected(); if (r!=null){ controller.adminEnableRoom(r.getId()); reload(); } }
  private void onDisable(){ Room r = selected(); if (r!=null){ controller.adminDisableRoom(r.getId()); reload(); } }
  private void onMaint(){ Room r = selected(); if (r!=null){ controller.adminMaintenance(r.getId()); reload(); } }

  private void onExport() {
    JFileChooser fc = new JFileChooser();
    fc.setSelectedFile(new File("recent_usage.csv"));
    if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
      try (Writer w = new OutputStreamWriter(new FileOutputStream(fc.getSelectedFile()), StandardCharsets.UTF_8)) {
        w.write("Room,User,Start,Check-in,Check-out,Used(min)\n");
        for (int i = 0; i < usageModel.getRowCount(); i++) {
          w.write(String.join(",", q(i,0), q(i,1), q(i,2), q(i,3), q(i,4), q(i,5)) + "\n");
        }
        msg.setText("Exported to " + fc.getSelectedFile().getName());
      } catch (Exception ex) { msg.setText("Export failed: " + ex.getMessage()); }
    }
  }
  private String q(int r,int c){ return "\"" + usageModel.getValueAt(r,c) + "\""; }

  static class UsageModel extends AbstractTableModel {
    private List<Booking> data = java.util.Collections.emptyList();
    private final String[] cols = {"Room","User","Start","Check-in","Check-out","Used (min)"};
    void setData(List<Booking> list){ data = (list==null)?java.util.Collections.emptyList():list; fireTableDataChanged(); }
    @Override public int getRowCount(){ return data.size(); }
    @Override public int getColumnCount(){ return cols.length; }
    @Override public String getColumnName(int c){ return cols[c]; }
    @Override public Object getValueAt(int r,int c){
      Booking b = data.get(r);
      switch (c){
        case 0: return b.getRoom().getName();
        case 1: return b.getUser().getName();
        case 2: return b.getWhen().start();
        case 3: return b.getCheckInTime();
        case 4: return b.getCheckOutTime();
        case 5: return b.usedMinutes();
        default: return "";
      }
    }
  }
}
