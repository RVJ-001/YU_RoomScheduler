package roomscheduler_view;

import javax.swing.*;
import java.awt.*;
import roomscheduler_controller.SystemController;
import roomscheduler_model_user.User;

public class CecAdminAccountsPanel extends JPanel {
  private static final long serialVersionUID = 1L;

  private final SystemController controller;

  public CecAdminAccountsPanel(SystemController controller) {
    super(new BorderLayout(10,10));
    this.controller = controller;

    JTextField name   = new JTextField();
    JTextField email  = new JTextField();
    JPasswordField pw = new JPasswordField();
    JPasswordField pw2= new JPasswordField();
    JTextField orgId  = new JTextField();

    JPanel form = new JPanel(new GridLayout(0,2,8,8));
    form.setBorder(BorderFactory.createTitledBorder("Create Admin (CEC only)"));
    form.add(new JLabel("Admin name:"));   form.add(name);
    form.add(new JLabel("Admin email:"));  form.add(email);
    form.add(new JLabel("Password:"));     form.add(pw);
    form.add(new JLabel("Confirm:"));      form.add(pw2);
    form.add(new JLabel("Org/Dept:"));     form.add(orgId);

    JButton create = new JButton("Create Admin");
    JLabel msg = new JLabel(" ");

    create.addActionListener(e -> {
      try {
        User cur = controller.getCurrentUser();
        if (cur == null) throw new SecurityException("Login required");
        if (!"cec@yorku.ca".equalsIgnoreCase(cur.getEmail()))
          throw new SecurityException("Only the CEC can create admins");

        String p1 = new String(pw.getPassword());
        String p2 = new String(pw2.getPassword());
        if (!p1.equals(p2)) throw new IllegalArgumentException("Passwords do not match");

        controller.cecCreateAdmin(cur.getEmail(), email.getText().trim(), p1, name.getText().trim());
        msg.setText("Admin created for: " + email.getText().trim());
        name.setText(""); email.setText(""); pw.setText(""); pw2.setText(""); orgId.setText("");
      } catch (Exception ex) {
        msg.setText(ex.getMessage());
      }
    });

    JPanel south = new JPanel(new BorderLayout());
    south.add(create, BorderLayout.CENTER);
    south.add(msg, BorderLayout.SOUTH);

    add(form, BorderLayout.CENTER);
    add(south, BorderLayout.SOUTH);
  }
}
