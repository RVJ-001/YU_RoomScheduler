package roomscheduler_model_payment;

public interface PaymentMethod {
    boolean processPayment(double amount);
}
