package roomscheduler_model_payment;

public class DebitCardPayment implements PaymentMethod {
  private final String cardNumber, holder, expiry;
  public DebitCardPayment(String cardNumber, String holder, String expiry) {
    this.cardNumber = cardNumber; this.holder = holder; this.expiry = expiry;
  }
  @Override public boolean processPayment(double amount) {
    return cardNumber != null && cardNumber.length() >= 10;
  }
  @Override public String toString(){ return "Debit(**" + cardNumber.substring(Math.max(0, cardNumber.length()-4)) + ")"; }
}
