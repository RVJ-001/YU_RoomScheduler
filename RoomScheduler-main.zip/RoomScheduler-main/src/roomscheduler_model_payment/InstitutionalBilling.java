package roomscheduler_model_payment;

public class InstitutionalBilling implements PaymentMethod {
    private final String deptOrAccount; // e.g., "ENG" or "Dept123"
    private final String reference;     // optional extra (e.g., account number)

    public InstitutionalBilling(String deptOrAccount) {
        this(deptOrAccount, "");
    }

    public InstitutionalBilling(String deptOrAccount, String reference) {
        this.deptOrAccount = (deptOrAccount == null) ? "" : deptOrAccount;
        this.reference     = (reference == null)     ? "" : reference;
    }

    @Override
    public boolean processPayment(double amount) {
        // Prototype: assume institutional charges are approved
        return true;
    }

    public String getDeptOrAccount() { return deptOrAccount; }
    public String getReference()     { return reference; }

    @Override
    public String toString() {
        return "InstitutionalBilling[" + deptOrAccount +
               (reference.isEmpty() ? "" : ("/" + reference)) + "]";
    }
}
