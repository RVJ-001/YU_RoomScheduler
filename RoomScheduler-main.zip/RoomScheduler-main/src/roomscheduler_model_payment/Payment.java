package roomscheduler_model_payment;

public class Payment {
  private final double amount;
  private final PaymentMethod method;
  public Payment(double amount, PaymentMethod method){
    this.amount = amount; this.method = method;
  }
  public boolean process() { return method != null && method.processPayment(amount); }
  public double getAmount(){ return amount; }
  public PaymentMethod getMethod(){ return method; }
}
