package roomscheduler_model_payment;

public enum PaymentType {
    CREDIT_CARD, DEBIT_CARD, INSTITUTIONAL_BILLING
}
