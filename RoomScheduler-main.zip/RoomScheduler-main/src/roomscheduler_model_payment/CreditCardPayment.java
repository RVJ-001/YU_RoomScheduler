package roomscheduler_model_payment;

public class CreditCardPayment implements PaymentMethod {
  private final String cardNumber, cardHolderName, expiry;
  private final String cvv;
  public CreditCardPayment(String cardNumber, String cardHolderName, String expiry, String cvv) {
    this.cardNumber = cardNumber; this.cardHolderName = cardHolderName; this.expiry = expiry; this.cvv = cvv;
  }
  @Override public boolean processPayment(double amount) {
    return cardNumber != null && cardNumber.length() >= 12 && cvv != null && cvv.length() >= 3;
  }
  @Override public String toString(){ return "CreditCard(**" + cardNumber.substring(Math.max(0, cardNumber.length()-4)) + ")"; }
}
