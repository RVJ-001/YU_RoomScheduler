package roomscheduler_model_payment;

public final class PaymentMethodFactory {
    private PaymentMethodFactory(){}

    /** Factory per the UML. */
    public static PaymentMethod create(PaymentType type, String a, String b, String c, String d) {
        switch (type) {
            case CREDIT_CARD:           // a=number, b=name, c=expiry, d=cvv
                return new CreditCardPayment(a, b, c, d);
            case DEBIT_CARD:            // a=number, b=name, c=expiry
                return new DebitCardPayment(a, b, c);
            case INSTITUTIONAL_BILLING: // a=deptOrAccount
                return new InstitutionalBilling(a);
            default:
                throw new IllegalArgumentException("Unsupported payment type: " + type);
        }
    }
}
