package roomscheduler_model_booking;

import java.time.*;
import roomscheduler_model.DateTimeRange;
import roomscheduler_model_room.Room;
import roomscheduler_model_user.User;

public class Booking {
    private final String bookingId;
    private final User user;
    private final Room room;
    private DateTimeRange when;
    private BookingStatus status = BookingStatus.CONFIRMED;

    private final double depositAmount;
    private double totalCost;

    private String checkInBadge;
    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;

    public Booking(String bookingId, User user, Room room, DateTimeRange when,
                   double depositAmount, double totalCost) {
        this.bookingId = bookingId;
        this.user = user;
        this.room = room;
        this.when = when;
        this.depositAmount = depositAmount;
        this.totalCost = totalCost;
    }

    public String getBookingId(){ return bookingId; }
    public User getUser(){ return user; }
    public Room getRoom(){ return room; }
    public DateTimeRange getWhen(){ return when; }
    public BookingStatus getStatus(){ return status; }
    public void setStatus(BookingStatus s){ this.status = s; }
    public double getDepositAmount(){ return depositAmount; }
    public double getTotalCost(){ return totalCost; }
    public String getCheckInBadge(){ return checkInBadge; }
    public java.time.LocalDateTime getCheckInTime(){ return checkInTime; }
    public java.time.LocalDateTime getCheckOutTime(){ return checkOutTime; }

    public void setCheckInBadge(String id){ this.checkInBadge = id; }
    public void markCheckedIn(LocalDateTime t){ this.checkInTime = t; }
    public void markCheckedOut(LocalDateTime t){ this.checkOutTime = t; }

    public void extendTo(DateTimeRange newRange, double newCost){
        this.when = newRange;
        this.totalCost = newCost;
    }

    /** Minutes between check-in and checkout (or now if not checked out). */
    public long usedMinutes(){
        if (checkInTime == null) return 0L;
        java.time.LocalDateTime end = (checkOutTime != null) ? checkOutTime : java.time.LocalDateTime.now();
        long mins = java.time.temporal.ChronoUnit.MINUTES.between(checkInTime, end);
        return Math.max(0L, mins);
    }

    @Override public String toString() {
        return room.getId() + " " + room.getName() + " [" +
               when.start() + " → " + when.end() + "] — " + status;
    }
}
