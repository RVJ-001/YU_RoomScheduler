package roomscheduler_model_booking;

public enum BookingStatus {
    CONFIRMED, CHECKED_IN, COMPLETED, CANCELLED, NO_SHOW
}
