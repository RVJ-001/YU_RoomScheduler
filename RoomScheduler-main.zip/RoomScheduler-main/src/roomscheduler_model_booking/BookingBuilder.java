package roomscheduler_model_booking;

import roomscheduler_model_user.User;
import roomscheduler_model_room.Room;
import roomscheduler_model.DateTimeRange;

public class BookingBuilder {
    private String id;
    private User user;
    private Room room;
    private DateTimeRange when;
    private double deposit;
    private double total;

    public BookingBuilder id(String v){ id = v; return this; }
    public BookingBuilder user(User v){ user = v; return this; }
    public BookingBuilder room(Room v){ room = v; return this; }
    public BookingBuilder when(DateTimeRange v){ when = v; return this; }
    public BookingBuilder deposit(double v){ deposit = v; return this; }
    public BookingBuilder total(double v){ total = v; return this; }

    public Booking build(){
        return new Booking(id, user, room, when, deposit, total);
    }
}
