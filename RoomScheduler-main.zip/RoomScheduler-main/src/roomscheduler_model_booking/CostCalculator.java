package roomscheduler_model_booking;

import roomscheduler_model_user.*;
import roomscheduler_model.DateTimeRange;
import java.time.Duration;

public class CostCalculator {
    public static double compute(User user, DateTimeRange when) {
        long hours = Math.max(1, Duration.between(when.start(), when.end()).toHours());
        double hourly;
        if (user instanceof Student) hourly = 20;
        else if (user instanceof Faculty) hourly = 30;
        else if (user instanceof Staff) hourly = 40;
        else if (user instanceof Partner) hourly = 50;
        else hourly = 25;
        return (10.0 + hourly) * hours; // base $10 + user rate
    }
    public static double deposit(double totalCost) {
        // “one hour’s fee upfront” ≈ hourly component + $10 base for one hour
        return Math.min(totalCost, 10.0 + (totalCost <= 10 ? 0 : (totalCost - 10))); // cap at total
    }
}
